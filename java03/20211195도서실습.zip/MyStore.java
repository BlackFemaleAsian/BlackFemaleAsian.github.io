package org.javaro.lecture;

public class MyStore {

	public static void main(String[] args) {
		BookStore testLibrary = new BookStore("지산 도서관");
		Book b1 = new Book();
		Book b2 = new Book();
		Book b3 = new Book();
		Book b4 = new Book();
		Book b5 = new Book();
		b1.setIsbn("9788954649001");
		b2.setIsbn("9788954649002");
		b3.setIsbn("9788954649003");
		b4.setIsbn("9788954649004");
		b5.setIsbn("9788954649005");
		b1.setTitle("춘향전");
		b2.setTitle("홍길동전");
		b3.setTitle("심청전");
		b4.setTitle("전쟁과평화");
		b5.setTitle("논어");
		b1.setAuthor("미상");
		b2.setAuthor("허균");
		b3.setAuthor("미상");
		b4.setAuthor("톨스토이");
		b5.setAuthor("공자");
		Student stud1 = new Student();
		Student stud2 = new Student();
		Student stud3 = new Student();
		Student stud4 = new Student();
		stud1.setStudNember("202X1001");
		stud2.setStudNember("202X1002");
		stud3.setStudNember("202X1003");
		stud4.setStudNember("202X1004");
		stud1.setName("홍길동");
		stud2.setName("성춘향");
		stud3.setName("변학도");
		stud4.setName("이몽룡");
		stud1.setMaxBooks(2);
		stud2.setMaxBooks(3);
		stud3.setMaxBooks(3);
		stud4.setMaxBooks(3);
		testLibrary.addBook(b1);
		testLibrary.addBook(b2);
		testLibrary.addBook(b3);
		testLibrary.addBook(b4);
		testLibrary.addBook(b5);
		testLibrary.addStudent(stud1);
		testLibrary.addStudent(stud2);
		testLibrary.addStudent(stud3);
		testLibrary.addStudent(stud4);
		System.out.println("도서관리 시스템 생성");
		testLibrary.printStatus();
		testLibrary.checkOut(b1, stud1);
		testLibrary.printStatus();
		testLibrary.checkOut(b3, stud1);
		testLibrary.printStatus();
		testLibrary.checkIn(b3);
		testLibrary.printStatus();
		testLibrary.checkOut(b3, stud3);
		testLibrary.printStatus();
		testLibrary.checkOut(b4, stud2);
		testLibrary.printStatus();
		testLibrary.checkOut(b5, stud3);
		testLibrary.printStatus();
		testLibrary.checkIn(b4);
		testLibrary.printStatus();
	}

}
